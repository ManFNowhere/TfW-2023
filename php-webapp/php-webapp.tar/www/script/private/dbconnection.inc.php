<?php
$servername       = "localhost";
$username       = "root";
$password   = "tanwirkhalid";
$db   = "login";