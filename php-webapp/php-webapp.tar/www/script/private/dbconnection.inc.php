<?php
$servername       = "localhost";
$username       = "root";
$password   = "tanwirkhalid";
$db   = "tmahdi_db";