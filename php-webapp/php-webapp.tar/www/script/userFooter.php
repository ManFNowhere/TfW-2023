
<footer class="u-align-center u-clearfix u-footer u-grey-70 u-footer" id="sec-1d0f">
        <div class="u-clearfix u-sheet u-sheet-1">
            <p class="u-small-text u-text u-text-variant u-text-1">powered by Hochschule Bremerhaven</p>
        </div>
    </footer>